# Voluntary project support / Ủng hộ tự nguyện

Author / Tác giả: **KabuchaDev**

YouTube: https://www.youtube.com/@KabuchaDev

Payment link / Đường dẫn nhận tiền: **not configured / chưa cấu hình**.

The mod and all included functions are free. If a lawful voluntary support channel is added later, contributing will be entirely optional and will not purchase anything or provide any entitlement. Non-contributors receive the same release, features, updates and access. There are no donor ranks, exclusive downloads, early access, priority support or guaranteed development requests.

Mod và toàn bộ chức năng đi kèm đều miễn phí. Nếu sau này bổ sung kênh ủng hộ phù hợp với các điều khoản áp dụng, việc ủng hộ hoàn toàn tự nguyện và không đổi lấy sản phẩm, tính năng, quyền truy cập, ưu tiên hỗ trợ hay cam kết làm yêu cầu riêng. Người không ủng hộ được sử dụng cùng một bản phát hành.

Project support is separate from the optional TikTok gift-to-spawn integration. TikTok gifts that trigger gameplay effects are **not** represented as no-benefit project donations. Operating and monetizing a livestream/server remains subject to the applicable Minecraft, platform and third-party rules.

Ủng hộ tác giả là khoản riêng, không nối vào bridge và không tạo quân trong game. Quà TikTok được ánh xạ để triệu hồi quân là tương tác có hiệu ứng trong game, không được gọi là khoản ủng hộ không có quyền lợi. Gói này không xác nhận cơ chế kiếm tiền đó được cấp phép.

Before activating any funding channel, review the current Minecraft EULA/Usage Guidelines and any necessary permissions. No permission or approval from Mojang/Microsoft has been obtained through this package. Changing `donationUrl` in `release.json` only records a link; no software functionality depends on it.
