# KabuchaDev JJK Arena 1.3.1 — Public Beta

Free Minecraft Java arena integration by **KabuchaDev**.

Author channel: https://www.youtube.com/@KabuchaDev

## Download and setup

Download **KabuchaDev-JJK-Arena-Free-1.3.1.zip** from this release's Assets. Extract it and read **HUONG-DAN-DAY-DU.md** (Vietnamese) or **COMPLETE-GUIDE-EN.md** (English) before setup. The ZIP includes original server/camera mods, source, local bridge, configuration and launch scripts.

Requires your own Minecraft Java 1.20.1 installation, Java 17, Forge 47.4.3 and matching Zeefski Jujutsu Kaisen Craft 3.2.1 client/server packs with Jujutsu Craft 50.1. Node.js 24+, TikFinity Desktop and Streamer.bot are used for the live interaction path. Third-party game/mod binaries are not bundled.

## Included

- Red vs blue arena, 10,000 HP cores, core shields and terrain protection.
- Four shared comment thresholds and 26 gift mappings covering 15 character types including Miwa, Nobara, Yuji, Gojo and Sukuna variants.
- One Streamer.bot action dispatches validated summon jobs.
- Spectator camera companion with left-Ctrl automatic follow toggle.
- New-viewer text welcome and deduplicated three-second follow bow scene.
- Gifts summon units and display thanks; no gift dance/cutscene or bundled music.
- Local troop test panel and complete installation/mapping documentation.

## Testing and limits

Build/reobfuscation, event-routing tests and 30 simulated bridge-to-dispatcher deliveries passed. This release has not yet completed a fresh full in-game client/server acceptance test. Treat it as a public beta, test before streaming and report reproducible issues with relevant versions and redacted logs.

The October 8 documentation update adds end-to-end English and Vietnamese guides, readable gift/character tables and GitHub publishing instructions. Mod binaries and gameplay behavior are unchanged by that documentation update.

## Free access

All included features are free. No activation key or donor-only features. A project support link is not configured; any future voluntary project contribution must provide no benefits in return and comply with applicable terms. TikTok gifts that affect gameplay are separate from project support. No claim of Minecraft monetization approval is made.

Not an official Minecraft product and not approved by or associated with Mojang or Microsoft. Jujutsu Craft and other dependencies belong to their respective authors. See LICENSE, SUPPORT.md and docs/RIGHTS.md in the package.
